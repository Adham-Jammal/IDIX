
  Swal.fire({
    icon: 'error',
    title: 'Something Went Wrong!',
    text: 'Please check your  input fields !',
  })
