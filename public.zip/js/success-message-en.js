Swal.fire(
    'Thank You!',
    'We will reply to you as soon as possible',
    'success'
  )
